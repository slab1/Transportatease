package com.example.transportatease

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 *
 */
class MapMakerActivity : AppCompatActivity() {
    /**
     *
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_maker)

    }
}